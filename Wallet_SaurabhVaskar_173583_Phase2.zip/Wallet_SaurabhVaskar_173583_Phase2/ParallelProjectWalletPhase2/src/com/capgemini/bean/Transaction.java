package com.capgemini.bean;

public class Transaction {
	private String type;
	private double amount, balance;

	public Transaction() {
	}
	//Transaction constructor with parameter
	public Transaction(String type, double amount, double balance) {

		this.type = type;
		this.amount = amount;
		this.balance = balance;
	}

	public String print() {
		return (type + "\t" + amount + "\t" + balance);
	}
}

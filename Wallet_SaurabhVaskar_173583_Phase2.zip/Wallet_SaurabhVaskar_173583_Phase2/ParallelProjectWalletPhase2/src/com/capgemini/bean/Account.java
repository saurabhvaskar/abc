package com.capgemini.bean;


public class Account {
	private int accNo; // backend will generate random code and assign it when openAccount()
	private String name;
	private long mobile;
	private String email;
	protected double balance;//opening account balance is 1000rs that will deposited when openAccount()

	public Account() {
	}

	public Account(String name, long mobile, String email) {
		this.name = name;
		this.mobile = mobile;
		this.email = email;
	}

	@Override
	public String toString() {
		return "A/C No = " + accNo + "\nName = " + name + "\nMobile = "
				+ mobile + "\nEmail = " + email + "\nBalance = " + balance;
	}

	public int getAccNo() {
		return accNo;
	}

	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getMobile() {
		return mobile;
	}

	public void setMobile(long mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

}


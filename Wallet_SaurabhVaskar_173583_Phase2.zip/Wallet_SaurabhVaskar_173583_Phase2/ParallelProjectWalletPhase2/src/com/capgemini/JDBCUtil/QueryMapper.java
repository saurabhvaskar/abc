package com.capgemini.JDBCUtil;

public interface QueryMapper {
	public String insertDetails="insert into bank values(seq_accno.nextval,?,?,?,?)";
	
	String sql= "Select * from bank where accno=?";
	
	String details="select * from bank where accno=(select max(accno)from bank)";
	
	String showbalance="select balance from bank where accno=?";
	
	String withdraw="update bank set balance=balance-? where accno=?";
	
	String deposite="update bank set balance=balance+? where accno=?";
	
	String transaction = "insert into transaction values(seq_trans.nextval,?,?,?,?)";
	
	String show = "select * from transaction where accno=? order by id";
}


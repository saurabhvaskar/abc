package com.capgemini.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.capgemini.JDBCUtil.JdbcUtil;
import com.capgemini.JDBCUtil.QueryMapper;
import com.capgemini.bean.Account;
import com.capgemini.bean.Transaction;
import com.capgemini.exception.BalanceException;
import com.capgemini.exception.RecordNotFoundException;

public class StoreUserdata implements StoreDataInterFace {
	// To save customer Data in map
	private Map<Integer, Account> accounts = new HashMap<Integer, Account>();
	private Map<Integer, ArrayList<Transaction>> transaction = new HashMap<Integer, ArrayList<Transaction>>();
	private ArrayList<Transaction> txns = null;
	private static int accountCounter = 1234502;

	Connection connection = null;
	PreparedStatement statement = null;

	public void openAccount(Account acc) {
		// txns = new ArrayList<Transaction>();
		acc.setAccNo(accountCounter);
		acc.setBalance(1000);
		accounts.put(accountCounter, acc);// Putting customer in map

		try {
			// getting JDBC connection
			try {
				connection = JdbcUtil.getConnection();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			statement = connection.prepareStatement(QueryMapper.insertDetails);
			// inserting details in table
			statement.setString(1, acc.getName());
			statement.setLong(2, acc.getMobile());
			statement.setString(3, acc.getEmail());
			statement.setDouble(4, acc.getBalance());
			statement.executeUpdate();

		} catch (SQLException e) {
			System.err.println("Unable to fetch data" + e);
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println(e);
			}
			try {
				statement.close();
			} catch (SQLException e) {
				System.out.println(e);
			}

		}

	}

	@Override
	public double showBalance(int accId) throws RecordNotFoundException {
		Account acc = accounts.get(accId);
		if (acc != null)
			return acc.getBalance();
		else
			throw new RecordNotFoundException(
					"Accound Record not found.\nFirst Open Account");
	}

	public Account fetchCustomer() {
		try {
			connection = JdbcUtil.getConnection();
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			statement = connection.prepareStatement(QueryMapper.details);
			ResultSet set = statement.executeQuery();
			if (set.next()) {
				// fetching data from table
				Account account = new Account(set.getString("Name"),
						set.getLong("MOBILE"), set.getString("EMAIL"));
				account.setAccNo(set.getInt("AccNo"));
				account.setBalance(set.getDouble("BALance"));
				return account;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	public double showBalance1(int userAccId) throws RecordNotFoundException {
		try {
			connection = JdbcUtil.getConnection();
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			statement = connection.prepareStatement(QueryMapper.showbalance);
			// passing user input
			statement.setInt(1, userAccId);
			ResultSet set = statement.executeQuery();
			if (set.next()) {
				// fetching balance from table
				return set.getDouble("Balance");
			}
		} catch (SQLException e) {

			e.printStackTrace();
		}
		throw new RecordNotFoundException(
				"Accound Record not found.\nFirst Open Account");

	}

	@Override
	public void deposit(int accID, double amount)
			throws RecordNotFoundException {
		try {
			connection = JdbcUtil.getConnection();
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		double balance = showBalance1(accID);
		if (balance >= 0) {
			try {
				statement = connection.prepareStatement(QueryMapper.deposite);
				// inserting details to deposit
				statement.setInt(2, accID);
				statement.setDouble(1, amount);
				statement.executeUpdate();
				// passing all details in transaction table
				insertIntoTransaction(accID, "CR", amount, amount + balance);

			} catch (SQLException e) {
				throw new RecordNotFoundException(
						"Accound Record not found.\nFirst Open Account");
			}

		} else
			throw new RecordNotFoundException(
					"Accound Record not found.\nFirst Open Account");
	}

	

	@Override
	public void Showtransaction(int userAccId) throws RecordNotFoundException {
	
		if (showBalance1(userAccId) >= 0) {
			try {
				connection = JdbcUtil.getConnection();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try {
				statement = connection.prepareStatement(QueryMapper.show);
				statement.setInt(1, userAccId);
				ResultSet rs = statement.executeQuery();
				System.out.println("Type\tAmount\tBalance");
				while (rs.next()) {
					// getting details from transaction table
					System.out.println(rs.getString("type") + "\t"
							+ rs.getDouble("amount") + "\t"
							+ rs.getDouble("Balance"));
				}
			} catch (SQLException e) {

				e.printStackTrace();
			}
		} else
			throw new RecordNotFoundException(
					"Accound Record not found.\nFirst Open Account");
	}

	@Override
	public void withdraw(int accId, double amount) throws BalanceException,
			RecordNotFoundException {
		try {
			connection = JdbcUtil.getConnection();
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		double balance = showBalance1(accId);
		if (balance >= amount) {
			try {
				statement = connection.prepareStatement(QueryMapper.withdraw);
				// passing all details in table
				statement.setInt(2, accId);
				statement.setDouble(1, amount);
				statement.executeUpdate();
				// passing all details in transaction table
				insertIntoTransaction(accId, "DR", amount, balance - amount);
			} catch (SQLException e) {

				e.printStackTrace();
			}

		} else
			throw new BalanceException("Insufficient balance");
	}


	public void fundTransfer(int source, int target, double amount)
			throws BalanceException, RecordNotFoundException {

		if (showBalance1(source) >= 0) {
			deposit(target, amount);
			withdraw(source, amount);
		} else
			throw new BalanceException("Insufficient balance");

	}

	@Override
	public Account findDetails(int AccNo) {
		try {

			Account account = new Account();
			try {
				connection = JdbcUtil.getConnection();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			statement = connection.prepareStatement(QueryMapper.sql);
			statement.setInt(1, AccNo);
			ResultSet rs = statement.executeQuery();
			if (rs.next()) {
				account.setAccNo(rs.getInt(1));
				account.setName(rs.getString(2));
				account.setMobile(rs.getLong(3));

				account.setEmail(rs.getString(4));

				account.setBalance(rs.getDouble(5));
				return account;
				/*
				 * statement.setLong(1, acc.getAccNo()); statement.setString(2,
				 * acc.getName()); statement.setLong(3, acc.getMobile());
				 * statement.setString(4, acc.getEmail());
				 * statement.setDouble(5, acc.getBalance());
				 */
			}

		} catch (SQLException e) {

			e.printStackTrace();
		}
		return null;

	}

	public void insertIntoTransaction(int accId, String type, double amount,
			double balance) {
		try {
			connection = JdbcUtil.getConnection();
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			statement = connection.prepareStatement(QueryMapper.transaction);
			statement.setInt(1, accId);
			statement.setDouble(3, amount);
			statement.setString(2, type);
			statement.setDouble(4, balance);
			statement.executeUpdate();
		} catch (SQLException e) {

			e.printStackTrace();
		}

	}

}

package com.capgemini.dao;

import com.capgemini.bean.Account;
import com.capgemini.exception.BalanceException;
import com.capgemini.exception.RecordNotFoundException;

public interface StoreDataInterFace {
	int MIN_BALANCE = 0;

	// creating methods for override
	void openAccount(Account acc);

	double showBalance(int accId) throws RecordNotFoundException;

	void deposit(int accID, double amount) throws RecordNotFoundException;

	void Showtransaction(int userAccId) throws RecordNotFoundException;

	void withdraw(int accId, double amount) throws BalanceException,
			RecordNotFoundException;

	void fundTransfer(int source, int target, double amount)
			throws BalanceException, RecordNotFoundException;

	Account findDetails(int AccNo);
}

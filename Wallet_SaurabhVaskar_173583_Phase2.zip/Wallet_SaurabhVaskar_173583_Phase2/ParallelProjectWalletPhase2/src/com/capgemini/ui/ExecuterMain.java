package com.capgemini.ui;

import java.util.Scanner;

import com.capgemini.JDBCUtil.JdbcUtil;
import com.capgemini.bean.Account;
import com.capgemini.dao.StoreUserdata;
import com.capgemini.exception.BalanceException;
import com.capgemini.exception.RecordNotFoundException;
import com.capgemini.service.ValidateUserInput;

	public class ExecuterMain {
		public static void main(String[] args) {
			StoreUserdata d=new StoreUserdata();	
			String ch;
			boolean isValid;
			String name;
			String email;
			String mobile;
			String userAccId;
			String amount;
			String sourceAccId;
			String targetAccId;
			ValidateUserInput userInput = new ValidateUserInput();
			
			
			System.out.println("\t\t\t=================================\n"
					+ "\t\t\tWelcome to wallet");
			Scanner sc = new Scanner(System.in);
			while (true) {
				while (true) {

					System.out
							.println("\t\t\t=================================\n"
									+ "\t\t\t1. Create Account\n"
									+ "\t\t\t2. Show Balance\n"
									+ "\t\t\t3. Deposite\n"
									+ "\t\t\t4. Withdraw\n"
									+ "\t\t\t5. Fund Transfer\n"
									+ "\t\t\t6. Show Transaction\n"
									+ "\t\t\t7. Find Details using id\n"
									+ "\t\t\t8. Exit\n"
									+ "\t\t\t=================================\n");
					ch = sc.next();
					isValid = userInput.validateEntry(ch);
					if (isValid)
						break; 											// if user enter valid input then break
					else
						System.out.println("Please enter Valid Choice 1 or 8");
				}
				switch (ch) {
				case "1":
					System.out.println("Welcome");
					while (true) {

						System.out.println("Enter name");
						name = sc.next();

						isValid = userInput.validateUserName(name);		// to validate UserName
						if (isValid)
							break; 										// if user enter valid input then break
						else
							System.out
									.println("Please enter Valid Name.\nName should have minimum 1 or max 10 character \nFirst letter must be capital");
					}
					while (true) {

						System.out.println("Enter Email");
						email = sc.next();
				
						isValid = userInput.validateEmail(email);		// to Validate User Email
						if (isValid)
							break;										// if user enter valid input then break
						else
							System.out
									.println("Please enter Valid Email(eg abc@gmail.com)");
					}
					while (true) {

						System.out.println("Enter mobile");
						mobile = sc.next();
				
						isValid = userInput.validateMobile(mobile);		// to validate user Mobile No
						if (isValid)
							break;										// if user enter valid input then break
						else
							System.out
									.println("Please enter Valid Mobile without +91 (eg. 1231231321)");
					}
					Account acc = new Account(name, Long.parseLong(mobile), email);
					userInput.openAccount(acc);
					System.out.println(userInput.fetchdetails());
					break;
				case "2":
					while (true) {
						System.out.println("Enter Account Id");
						userAccId = sc.next();
						isValid = userInput.validateAccId(userAccId);
						if (isValid)
							break; 										// if user enter valid input then break
						else
							System.out
									.println("Please enter Valid Account Id eg.1231231");
					}
					try {
						System.out.println("Balance="+userInput.showBalance1(Integer.parseInt(userAccId)));
					} catch (NumberFormatException | RecordNotFoundException e1) {
						System.out.println(e1);
					} 
					break;
				case "3":
					while (true) {
						System.out.println("Enter Account Id");
						userAccId = sc.next();
						isValid = userInput.validateAccId(userAccId);
						if (isValid)
							break; 										// if user enter valid input then break
						else
							System.out
									.println("Please enter Valid Account Id eg.1231231");
					}
					while (true) {
						System.out.println("Enter Amount");
						amount = sc.next();
						isValid = userInput.validateAmount(amount);
						if (isValid)
							break; 										// if user enter valid input then break
						else
							System.out.println("Please enter Amount eg.7000");
					}
					try {
						userInput.deposit(Integer.parseInt(userAccId),
								Double.parseDouble(amount));
						System.out.println("Transaction Successful");
					} catch (NumberFormatException | RecordNotFoundException e) {
						System.out.println(e);
					}

					break;
				case "4":
					while (true) {
						System.out.println("Enter Account Id");
						userAccId = sc.next();
						isValid = userInput.validateAccId(userAccId);
						if (isValid)
							break; 										// if user enter valid input then break
						else
							System.out
									.println("Please enter Valid Account Id eg.1231231");
					}
					while (true) {
						System.out.println("Enter Amount");
						amount = sc.next();
						isValid = userInput.validateAmount(amount);
						if (isValid)
							break; 										// if user enter valid input then break
						else
							System.out.println("Please enter Amount eg.7000");
					}
					try {
						userInput.withdraw(Integer.parseInt(userAccId),
								Double.parseDouble(amount));
						System.out.println("Transaction Successful");
					} catch (NumberFormatException | BalanceException
							| RecordNotFoundException e) {
						System.out.println(e);
					}
					
					break;
				case "5":
					while (true) {
						System.out.println("Enter your Account Id");
						sourceAccId = sc.next();
						isValid = userInput.validateAccId(sourceAccId);
						if (isValid)
							break; 									// if user enter valid input then break
						else
							System.out
									.println("Please enter Valid Account Id eg.1231231");
					}
					while (true) {
						System.out.println("Enter receipent Account Id");
						targetAccId = sc.next();
						isValid = userInput.validateAccId(targetAccId);
						if (isValid)
							break; 									// if user enter valid input then break
						else
							System.out
									.println("Please enter Valid Account Id eg.1231231");
					}
					while (true) {
						System.out.println("Enter Fund transfer Amount");
						amount = sc.next();
						isValid = userInput.validateAmount(amount);
						if (isValid)
							break; // if user enter valid input then break
						else
							System.out.println("Please enter Amount eg.7000");
					}
					userInput.fundTransfer(Integer.parseInt(sourceAccId),
							Integer.parseInt(targetAccId),
							Double.parseDouble(amount));
					System.out.println("Transaction Successful");
					break;
				case "6":
					while (true) {
						System.out.println("Enter Account Id");
						userAccId = sc.next();
						isValid = userInput.validateAccId(userAccId);
						if (isValid)
							break; // if user enter valid input then break
						else
							System.out
									.println("Please enter Valid Account Id eg.1231231");
					}
					try {
						userInput.Showtransaction(Integer.parseInt(userAccId));
					} catch (NumberFormatException | RecordNotFoundException e) {
						System.out.println(e);
					}
					break;
				case "7" :
					System.out.println("Enter Account Id");
					System.out.println("Your Account Details are: "+d.findDetails(sc.nextInt()));
					break;
					
				
				case "8":
					System.out.println("\t\t\t=====================/n"
							+ "\t\t\tTerminationg program\n"
							+ "\t\t\t=====================");

					System.exit(0);
					break;
				
				default:
					break;
				}
			}
		}
	}



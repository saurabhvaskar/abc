package com.capgemini.service;

import com.capgemini.bean.Account;
import com.capgemini.exception.BalanceException;
import com.capgemini.exception.RecordNotFoundException;



public interface ValidateInterface {
	// Matches pattern string
	String ENTRY = "[1-8]{1}";
	String ACC_NO = "[0-9]{7}";
	String AMOUNT = "[0-9]{1,10}";
	String USER_NAME_PATTERN = "[a-zA-Z]{1,10}";
	String ADDRESS_PATTERN = "[A-Za-z]{1,25}";
	String MOBILE_PATTERN = "[0-9]{10}";
	String EMAIL_PATTERN = "^[\\w-\\+]+(\\.[\\w]+)*@[\\w-]+(\\.[\\w]+)*(\\.[a-z]{2,})$";

	// String CUST_ID="[0-9]{1,4}";

	// creating methods for validates user Input
	boolean validateUserName(String userName);

	boolean validateMobile(String mobile);

	boolean validateEmail(String email);

	boolean validateEntry(String ch);

	boolean validateAccId(String userAccId);

	void openAccount(Account acc);

	double showBalance(int accId) throws RecordNotFoundException;

	void deposit(int accId, double amount) throws RecordNotFoundException;

	void Showtransaction(int userAccId) throws RecordNotFoundException;

	void withdraw(int accId, double amount) throws BalanceException, RecordNotFoundException;

	void fundTransfer(int source, int target, double amount);
	

	Account findDetails(int AccNo);
}

package com.capgemini.test;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features= {"feature"},//feature folder path
		glue = {"com.capgemini.step"}//step definition path
		
		)
public class testRunner {

}

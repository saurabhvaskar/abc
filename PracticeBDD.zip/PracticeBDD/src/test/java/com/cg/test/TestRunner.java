package com.cg.test;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features = { "src/test/resources/feature1/person.feature",
							  "src/test/resources/feature2/education.feature" },
				glue = { "com.cg.step" }/*, tags = { "@Second" }*/)
public class TestRunner {

}

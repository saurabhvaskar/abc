package com.cg.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class Education {

	@FindBy(id = "edubtn")
	private WebElement eduButton;

	@FindBy(id = "graduation")
	private WebElement graduation;

	@FindBy(id = "percentage")
	private WebElement percentage;

	@FindBy(id = "passingYear")
	private WebElement passingYear;

	@FindBy(id = "projectName")
	private WebElement projectName;

	@FindBy(id = "technology")
	private WebElement technology;

	@FindBy(id = "otherTech")
	private WebElement othertech;

	public void button() {
		eduButton.click();
	}

	public void Graduation(int gIndex) {
		Select select = new Select(graduation);
		select.selectByIndex(gIndex);
	}

	public String getPercentage() {
		return percentage.getAttribute("value");
	}

	public void setPercentage(String percentage) {
		this.percentage.sendKeys(percentage);
	}

	public String getPassingYear() {
		return passingYear.getAttribute("value");
	}

	public void setPassingYear(String passingYear) {
		this.passingYear.sendKeys(passingYear);
	}

	public void technology(int tIndex) {
		Select select = new Select(technology);
		select.selectByIndex(tIndex);
	}

	public String getProjectName() {
		return projectName.getAttribute("value");
	}

	public void setProjectName(String projectName) {
		this.projectName.sendKeys(projectName);
	}

	public String getOthertech() {
		return othertech.getAttribute("value");
	}

	public void setOthertech(String othertech) {
		this.othertech.sendKeys(othertech);
	}
}

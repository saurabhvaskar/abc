package com.cg.step;

import org.openqa.selenium.Alert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.Education;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class EducationStepDefinition {

	WebDriver driver;
	Education edu;
	
	@Before
	public void init() {
		// instantiate driver
		System.setProperty("webdriver.chrome.driver", "mydriver\\chromedriver.exe");
		
	}
	
	@After
	public void destroy() {
		System.out.println("scenario ended!!!!");
	}
	
	@Given("^user is on education page$")
	public void user_is_on_education_page() throws Throwable {
		driver = new ChromeDriver();
		edu = new Education();
		PageFactory.initElements(driver, edu);// for mapping web with bean
		driver.manage().window().maximize();
		
		driver.get("C:\\Users\\svaskar\\Desktop\\mail\\PracticeBDD\\html\\EducationDetails.html");
	      
	}

	@Then("^edu validate title$")
	public void edu_validate_title() throws Throwable {
		 JavascriptExecutor scriptExecutor = (JavascriptExecutor) driver;
			if (driver.getTitle().equals("Education Details")) {
				//System.out.println("you are on correct page");	
				Thread.sleep(2000);
				scriptExecutor.executeScript("alert('you are on correct page!')");
				
				Thread.sleep(2000);		
				Alert alert = driver.switchTo().alert();
				alert.accept();
			} else {
				//System.out.println("Wrong page!!!!!!");
				scriptExecutor.executeScript("alert('Wrong page!')");
				Thread.sleep(5000);
				Alert alert = driver.switchTo().alert();
				alert.accept();
				
			}
			driver.quit();
	}

	@Given("^user is on edu page$")
	public void user_is_on_edu_page() throws Throwable {
		driver = new ChromeDriver();
		edu = new Education();
		PageFactory.initElements(driver, edu);// for mapping web with bean
		driver.manage().window().maximize();
		
		driver.get("C:\\Users\\svaskar\\Desktop\\mail\\PracticeBDD\\html\\EducationDetails.html");
	      
	}

	@When("^invalid gradu$")
	public void invalid_gradu() throws Throwable {
	    edu.Graduation(0);
	    edu.setPercentage("45");
	    edu.setPassingYear("2015");
	    edu.setProjectName("dabra");
	    edu.technology(5);
	    edu.setOthertech("garba");
	       
	}

	@Then("^edu validation$")
	public void edu_validation() throws Throwable {
		edu.button();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(6000);
	    
		driver.quit();
	}

	@When("^invalid percent$")
	public void invalid_percent() throws Throwable {
		   edu.Graduation(1);
		    edu.setPercentage("4");
		    edu.setPassingYear("2011");
		    edu.setProjectName("dabra");
		    edu.technology(5);
		    edu.setOthertech("garba");
	      
	}

	@When("^invalid passing year$")
	public void invalid_passing_year() throws Throwable {
		   edu.Graduation(1);
		    edu.setPercentage("45");
		    edu.setPassingYear("200");
		    edu.setProjectName("dabra");
		    edu.technology(5);
		    edu.setOthertech("garba");
	      
	}

	@When("^invalid proj name$")
	public void invalid_proj_name() throws Throwable {
		   edu.Graduation(1);
		    edu.setPercentage("45");
		    edu.setPassingYear("2015");
		    edu.setProjectName("");
		    edu.technology(2);
		    
	      
	}

	@When("^invalid techno$")
	public void invalid_techno() throws Throwable {
	     
		   edu.Graduation(1);
		    edu.setPercentage("45");
		    edu.setPassingYear("2015");
		    edu.setProjectName("dabra");
		    edu.technology(0);
		    
	}

	@When("^other techno invalid details$")
	public void other_techno_invalid_details() throws Throwable {
	     
		   	edu.Graduation(1);
		    edu.setPercentage("45");
		    edu.setPassingYear("2015");
		    edu.setProjectName("dabra");
		    edu.technology(5);
		    edu.setOthertech("");
	}

	@When("^Perfect details$")
	public void perfect_details() throws Throwable {
	     
		   	edu.Graduation(1);
		    edu.setPercentage("45");
		    edu.setPassingYear("2015");
		    edu.setProjectName("dabra");
		    Thread.sleep(2000);
		    edu.technology(5);
		    edu.setOthertech("garba");
	}
}
